const getName = () => {
    return 'Tom';
};
const getLocation = () => {
    return 'Harry';
};
const dateOfBirth = '07.01.1900';
exports.getName = getName;
exports.getLocation = getLocation;
exports.dob = dateOfBirth;